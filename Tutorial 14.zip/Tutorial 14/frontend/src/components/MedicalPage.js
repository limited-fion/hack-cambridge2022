import React, { Component } from "react";
import { render } from "react-dom";
import { Grid, Button, ButtonGroup, Typography } from "@material-ui/core";

export default class MedicalPage extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Grid>
        nihao
      </Grid>
    );
  }
}
