import React, { Component } from "react";
import { Grid, Button, ButtonGroup, Typography } from "@material-ui/core";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import { render } from "react-dom";
import HomePage from "./HomePage";

function onePost() {
  this.code = null;
  this.content=null;
  this.created_at=null;
}

function makePosts(data) {
  const n = data.length;
  var posts = new Array(n);
  for (var i = 0; i < n; ++i) {
    posts[i] = new onePost();
    posts[i].code = data[i].code;
    posts[i].content = data[i].content;
    posts[i].created_at = data[i].created_at;
  }
  console.log(posts[1])
  return posts
}
function getPostTag() {
  const received = fetch("/api/get-tag" + "?tag=" + "food").then((response)=>{
    return response.json()
  })
  .then((data)=>{makePosts(data)});
}

export default class FoodPage extends Component {
  constructor(props) {
    super(props);
  }
  // this.makePosts = this.makePosts.bind(this);
  // this.getPostTag = this.getPostTag.bind(this);
  
  // makePosts(data) {
  //   const n = data.length;
  //   var posts = new Array(n);
  //   for (var i = 0; i < n; ++i) {
  //     posts[i] = new onePost();
  //     posts[i].code = data[i].code;
  //     posts[i].content = data[i].content;
  //     posts[i].created_at = data[i].created_at;
  //   }
  //   return posts
  // }
  // getPostTag() {
  //   fetch("/api/get-tag" + "?tag=" + "food")
  //   .then((response)=>{
  //     return response.json()
  //   })
  //   .then((data)=>{makePosts(data)});
  // }

  render() {
      // const n = 100;
      // tmp = new Array(n);
      // for(int m = 0; m < tmp; ++m){
      //   tmp[m] = new onePost();
      // }
      // tmp = getPostTag;
      var test
      return (
        <Grid item xs={12} align="center">
          <Button color="primary" variant="contained" xs={4} onClick={test = getPostTag}>
            Show Posts
          </Button>
      
          <Button color="primary" variant="contained" to="/" component={Link} xs={4}>
            Back
          </Button>
          <Typography variant="h4" component="h4">
            ajidsi
          </Typography>
        </Grid>
        
        
        // <Grid item xs={12} align="center">
        //   <Typography variant="h4" component="h4">
            
        //   </Typography>
        // </Grid>

    //   <Router>
    //       <Switch>
    //         <Route exact path="/" component={HomePage}/>
    //       </Switch>
    //     </Router>
       );
    }
}



// function FoodPage(){
//   return(
//     <Grid item xs={12} align="center">
//       <Button color="primary" variant="contained" to="/" component={Link} xs={4}>
//         Back
//       </Button>
//     </Grid>

        // tmp = getPostTag;
        // for (let i = 0; i < len(tmp); i++) {
        // <Grid item xs={12} align="center">
        //     <Button
        //     color="primary"
        //     variant="contained"
        //     xs={12}
        //     //onClick={this.handleVoiceInput}
        //     >
//     )
// }

// export default FoodPage

// export default class FoodPage extends Component {
//     // constructor(props) {
//     //     super(props);
//     //     this.state = {
//     //     votesToSkip: 2,
//     //     guestCanPause: false,
//     //     isHost: false,
//     //     showSettings: false,
//     //     spotifyAuthenticated: false,
//     //     song: {},
//     //    };
//     //     this.roomCode = this.props.match.params.roomCode;
//     //     this.leaveButtonPressed = this.leaveButtonPressed.bind(this);
//     //     this.updateShowSettings = this.updateShowSettings.bind(this);
//     //     this.renderSettingsButton = this.renderSettingsButton.bind(this);
//     //     this.renderSettings = this.renderSettings.bind(this);
//     //     this.getRoomDetails = this.getRoomDetails.bind(this);
//     //     this.authenticateSpotify = this.authenticateSpotify.bind(this);
//     //     this.getCurrentSong = this.getCurrentSong.bind(this);
//     //     this.getRoomDetails();
//       this.getPostTag = this.getPostTag.bind(this);
//      }

    

//     getPostTag() {
//         return fetch("/api/get-tag" + "?tag=" + "food")
//         .then((response) => {
//             if (!response.ok) {
//             this.props.leaveRoomCallback();
//             this.props.history.push("/");
//             }
//             return response.json();
//         })
//         .then((data)=>{makePosts(data)});
//         //     (data) => {
//         //     this.setState({
//         //     votesToSkip: data.votes_to_skip,
//         //     guestCanPause: data.guest_can_pause,
//         //     isHost: data.is_host,
//         //     });
//         //     if (this.state.isHost) {
//         //     this.authenticateSpotify();
//         //     }
//         // });
//     }
// //tmp = this.getPostTag;
//   //     tmp = this.getPostTag;
//   //     for (let i = 0; i < len(tmp); i++) {
//   //       <Grid item xs={12} align="center">
//   //         <Button
//   //           color="primary"
//   //           variant="contained"
//   //           xs={12}
//   //           //onClick={this.handleVoiceInput}
//   //         >
            
//   //         </Button>
//   //       </Grid>
//   //     }
  
